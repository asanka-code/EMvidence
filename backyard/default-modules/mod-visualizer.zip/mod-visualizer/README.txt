This module produces visualizations of EM traces. This is a default module in EMvidence.
